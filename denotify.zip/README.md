## Google+ Notification Icon Hider

A simple Chrome extension that hides the Google+ notification icon on Google apps except Google+.

<img src="icon.png">
<img src="remove_not.png">
